<?php
require __DIR__.'/vendor/autoload.php';

$app = new \Slim\App;

$app->get('/hello', function()
{
    return 'hello word';
});
$app->run();
