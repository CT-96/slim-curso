<?php
require __DIR__.'/../bootstrap.php';